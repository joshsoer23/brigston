<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'joshsoer_zyqu');

/** MySQL database username */
define('DB_USER', 'joshsoer_zyqu');

/** MySQL database password */
define('DB_PASSWORD', 'nktosqqko9iebg31');

/** MySQL hostname */
define('DB_HOST', '10.169.0.169');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'YIWlkwebAFKSnqUJtI643w22dIqZqn13emHkcACbdXpKbCsZ8PHgYiXiSAsGFoqX');
define('SECURE_AUTH_KEY',  'OwyWRqPAOYBPKJ0hQoW6UZ9CCB2cQCzsevbO7DtJGgCN1itn4Vb4fvnPtSAniv8Q');
define('LOGGED_IN_KEY',    'IJ223jt0FoMjhWm7gJapH7fImqvB3w6qdTdm3zPFpgOAI3oDL61oZdMcYdtPz3cj');
define('NONCE_KEY',        'CQiBnM5pko9zN6xRXZwiOxSv9lcDHreP0hLQoPgS21jNpPuTKGTV7YYtSrR8nzR2');
define('AUTH_SALT',        'A3aGhvFGe4yl7qPzu8YqlVv4wkxOuw5TR54Rgg6RO6CTpFJg0umAU79Can190bdB');
define('SECURE_AUTH_SALT', '0erBK3LeYOczfA0EsflPNNgrs83DJY5UTlT78AZfLAmV9z5LvssnPTEIMIKUsyVD');
define('LOGGED_IN_SALT',   'QW2pcvNNNc3FIQDUlGCrNM7CGIFfitpADyZRtR62HxRmiB4awGmkskyOAN5UMezE');
define('NONCE_SALT',       'cjBwnZaEYq5ovmz80PJ5yTieR7sI16MSQdYEduhShxCNN9drzHqn49ykN7SBw2SV');

/**
 * Other customizations.
 */
define('FS_METHOD','direct');define('FS_CHMOD_DIR',0755);define('FS_CHMOD_FILE',0644);
define('WP_TEMP_DIR',dirname(__FILE__).'/wp-content/uploads');

/**
 * Turn off automatic updates since these are managed upstream.
 */
define('AUTOMATIC_UPDATER_DISABLED', true);


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'me3q_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
